# InternHub – College Internship Portal

## Project Overview

InternHub is a web-based internship portal that connects students with companies offering internship opportunities. Students can create profiles, upload resumes, search for internships, and track their applications. Companies can publish internships and manage applicants.

This project is designed to run in restricted PHP environments such as ByteXL, even when MySQL-related PHP extensions are unavailable.

## Features

### Student Features
- Student registration and login
- Secure password hashing
- Student profile management
- PDF resume upload (maximum 5 MB)
- Internship search by keyword and location
- Apply for internships
- Duplicate application prevention
- Track application status

### Company Features
- Company registration and login
- Publish internship opportunities
- Manage internship listings
- Open or close internships
- View student applications
- Update applicant status

### Technical Features
- PHP-based application
- JSON file storage
- Session-based authentication
- Responsive user interface
- Input validation
- Resume upload validation
- No MySQL PHP extension required

## Technologies Used

- Frontend: HTML, CSS, JavaScript
- Backend: PHP
- Data Storage: JSON
- Authentication: PHP Sessions
- Resume Format: PDF

## Project Structure

```text
internship-portal/
├── index.php
├── login.php
├── register.php
├── logout.php
├── student/
│   └── dashboard.php
├── company/
│   └── dashboard.php
├── config/
│   └── database.php
├── css/
│   └── style.css
├── js/
│   └── validation.js
├── uploads/
├── data/
└── README.md
```

Note: The actual folders and files may differ depending on your project version.

## How to Run the Project

1. Open your project in ByteXL.
2. Check that all PHP files and folders are present.
3. Ensure the application can write to its required data and upload directories.
4. Open the terminal in the project environment.
5. Start the PHP development server using the correct project path:

```bash
php -S 0.0.0.0:8080 -t .
```

6. Open the forwarded port URL provided by ByteXL.
7. Register a student account and test the login.
8. Register a company account and publish an internship.
9. Test internship applications and applicant status updates.
10. Test logout and confirm that protected pages require authentication.

## Data Storage

The application stores data in JSON files rather than requiring a MySQL server. The configured storage directory must be writable by PHP.

The application may use a private directory such as `internhub_data/` instead of the project's `data/` folder, depending on the implementation in `config/database.php`.

## Security

- Passwords should be stored using PHP `password_hash()`.
- Login passwords should be checked using `password_verify()`.
- User input should be validated and escaped.
- Uploaded resumes should be validated for file type and size.
- Protected pages should check the user's session and role.
- Private data files should not be directly accessible through the web server.

## Future Enhancements

- MySQL database integration
- Email notifications
- Advanced internship filters
- Application analytics
- Interview scheduling
- Admin dashboard

## Conclusion

InternHub provides a simple platform for students to discover internship opportunities and for companies to manage recruitment activities. JSON storage makes the project suitable for restricted PHP environments where MySQL extensions are unavailable.
