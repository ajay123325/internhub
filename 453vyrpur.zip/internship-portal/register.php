<?php

session_start();

require_once __DIR__ . '/config/database.php';

$data = db_load();

$error = '';
$success = '';

$name = '';
$email = '';
$role = 'student';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $name = trim($_POST['name'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $password = (string) ($_POST['password'] ?? '');
    $role = $_POST['role'] ?? 'student';

    if ($name === '' || $email === '' || $password === '') {

        $error = 'Please fill in all required fields.';

    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {

        $error = 'Please enter a valid email address.';

    } elseif (strlen($password) < 6) {

        $error = 'Password must contain at least 6 characters.';

    } elseif (!in_array($role, ['student', 'company'], true)) {

        $error = 'Please select a valid account type.';

    } elseif (db_find_user_by_email($data, $email)) {

        $error = 'An account with this email already exists.';

    } else {

        $userId = db_next_id($data, 'users');

        $data['users'][] = [
            'id'         => $userId,
            'name'       => $name,
            'email'      => $email,
            'password'   => password_hash(
                $password,
                PASSWORD_DEFAULT
            ),
            'role'       => $role,
            'created_at' => db_now()
        ];

        if ($role === 'student') {

            $data['students'][] = [
                'id'       => db_next_id($data, 'students'),
                'user_id'  => $userId,
                'phone'    => '',
                'college'  => '',
                'course'   => '',
                'skills'   => '',
                'bio'      => '',
                'resume'   => ''
            ];

        } else {

            $data['companies'][] = [
                'id'           => db_next_id($data, 'companies'),
                'user_id'      => $userId,
                'company_name' => $name,
                'website'      => '',
                'description'  => ''
            ];
        }

        if (db_save($data)) {

            $success = 'Account created successfully! Please sign in.';

            $name = '';
            $email = '';
            $role = 'student';

        } else {

            $error = 'Unable to save account. Check data folder permissions.';
        }
    }
}

function e($value)
{
    return htmlspecialchars(
        (string) $value,
        ENT_QUOTES,
        'UTF-8'
    );
}

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">

    <meta name="viewport"
          content="width=device-width, initial-scale=1.0">

    <title>Create Account | InternHub</title>

    <link rel="stylesheet" href="css/style.css">
</head>

<body class="auth-page">

    <div class="auth-container">

        <div class="auth-brand">

            <a href="index.php" class="logo">
                Intern<span>Hub</span>
            </a>

            <p class="eyebrow" style="margin-top: 55px;">
                INTERNSHIP PORTAL
            </p>

            <h1>Turn ambition into experience.</h1>

            <p>
                Build your profile, discover internship
                opportunities, and track your applications
                in one simple workspace.
            </p>

        </div>

        <div class="auth-card">

            <h2>Create Your Account</h2>

            <p class="muted">
                Choose your account type and get started.
            </p>

            <?php if ($error !== ''): ?>

                <div class="alert error" role="alert">
                    <?= e($error) ?>
                </div>

            <?php endif; ?>

            <?php if ($success !== ''): ?>

                <div class="alert success" role="status">
                    <?= e($success) ?>
                </div>

            <?php endif; ?>

            <form
                method="POST"
                action="register.php"
                onsubmit="return validateRegister()"
            >

                <label for="name">Full Name</label>

                <input
                    type="text"
                    name="name"
                    id="name"
                    value="<?= e($name) ?>"
                    placeholder="Enter your full name"
                    maxlength="100"
                    autocomplete="name"
                    required
                >

                <label for="email">Email Address</label>

                <input
                    type="email"
                    name="email"
                    id="email"
                    value="<?= e($email) ?>"
                    placeholder="you@example.com"
                    autocomplete="email"
                    required
                >

                <label for="password">Password</label>

                <input
                    type="password"
                    name="password"
                    id="password"
                    placeholder="At least 6 characters"
                    minlength="6"
                    autocomplete="new-password"
                    required
                >

                <label for="role">Account Type</label>

                <select name="role" id="role" required>

                    <option value="student"
                        <?= $role === 'student' ? 'selected' : '' ?>>
                        Student
                    </option>

                    <option value="company"
                        <?= $role === 'company' ? 'selected' : '' ?>>
                        Company
                    </option>

                </select>

                <button
                    class="btn primary full"
                    type="submit"
                >
                    Create Account
                </button>

            </form>

            <p class="auth-bottom">
                Already registered?
                <a href="login.php">Sign in</a>
            </p>

            <p class="auth-bottom">
                <a href="index.php">Back to Home</a>
            </p>

        </div>

    </div>

    <script src="js/validation.js"></script>

</body>
</html>
