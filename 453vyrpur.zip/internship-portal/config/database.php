<?php
/**
 * InternHub - Storage Configuration
 * JSON datastore for ByteXL PHP environments
 */

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Database credentials (for future MySQL deployment)
const DB_HOST = 'db01.dbhost.dev';
const DB_PORT = 5051;
const DB_NAME = 'db_455n3t49d';
const DB_USER = 'user_455n3t49d';
const DB_PASS = 'user_455n3t49d';

// JSON storage location
define('DATA_DIR', dirname(__DIR__, 2) . '/internhub_data');
define('DATA_FILE', DATA_DIR . '/portal.json');

/**
 * Default data structure
 */
function db_default(): array
{
    return [
        'users' => [],
        'students' => [],
        'companies' => [],
        'internships' => [],
        'applications' => [],
        'counters' => [
            'users' => 0,
            'students' => 0,
            'companies' => 0,
            'internships' => 0,
            'applications' => 0,
        ],
    ];
}

/**
 * Create the storage directory and JSON file
 */
function db_boot(): void
{
    if (!is_dir(DATA_DIR)) {
        if (!@mkdir(DATA_DIR, 0775, true) && !is_dir(DATA_DIR)) {
            error_log('InternHub: Unable to create storage directory.');
            return;
        }
    }

    if (!file_exists(DATA_FILE)) {
        $json = json_encode(
            db_default(),
            JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE
        );

        if ($json === false || @file_put_contents(DATA_FILE, $json, LOCK_EX) === false) {
            error_log('InternHub: Unable to initialize JSON storage.');
        }
    }
}

/**
 * Load stored data
 */
function db_load(): array
{
    db_boot();

    if (!is_readable(DATA_FILE)) {
        return db_default();
    }

    $raw = @file_get_contents(DATA_FILE);

    if ($raw === false || trim($raw) === '') {
        return db_default();
    }

    $data = json_decode($raw, true);

    if (!is_array($data)) {
        error_log('InternHub: Stored JSON data is invalid.');
        return db_default();
    }

    $defaults = db_default();

    foreach ($defaults as $key => $value) {
        if (!isset($data[$key]) || !is_array($data[$key])) {
            $data[$key] = $value;
        }
    }

    foreach ($defaults['counters'] as $key => $value) {
        if (!isset($data['counters'][$key])) {
            $data['counters'][$key] = $value;
        }
    }

    return $data;
}

/**
 * Save data safely
 */
function db_save(array $data): bool
{
    db_boot();

    if (!is_dir(DATA_DIR) || !is_writable(DATA_DIR)) {
        error_log('InternHub: Storage directory is not writable.');
        return false;
    }

    $json = json_encode(
        $data,
        JSON_PRETTY_PRINT |
        JSON_UNESCAPED_UNICODE |
        JSON_UNESCAPED_SLASHES
    );

    if ($json === false) {
        error_log('InternHub: Failed to encode data.');
        return false;
    }

    $tempFile = DATA_FILE . '.tmp';

    if (@file_put_contents($tempFile, $json, LOCK_EX) === false) {
        error_log('InternHub: Failed to write temporary data file.');
        return false;
    }

    if (!@rename($tempFile, DATA_FILE)) {
        @unlink($tempFile);
        error_log('InternHub: Failed to save data file.');
        return false;
    }

    return true;
}

/**
 * Generate the next record ID
 */
function db_next_id(array &$data, string $table): int
{
    if (!isset($data['counters'][$table])) {
        $data['counters'][$table] = 0;
    }

    $data['counters'][$table]++;

    return (int) $data['counters'][$table];
}

/**
 * Current date and time
 */
function db_now(): string
{
    return date('Y-m-d H:i:s');
}

/**
 * Find a user by email address
 */
function db_find_user_by_email(array $data, string $email): ?array
{
    foreach ($data['users'] as $user) {
        if (
            isset($user['email']) &&
            strcasecmp((string) $user['email'], trim($email)) === 0
        ) {
            return $user;
        }
    }

    return null;
}

/**
 * Find a user by ID
 */
function db_user(array $data, int $id): ?array
{
    foreach ($data['users'] as $user) {
        if (isset($user['id']) && (int) $user['id'] === $id) {
            return $user;
        }
    }

    return null;
}

/**
 * Find student profile by user ID
 */
function db_student_by_user(array $data, int $userId): ?array
{
    foreach ($data['students'] as $row) {
        if (isset($row['user_id']) && (int) $row['user_id'] === $userId) {
            return $row;
        }
    }

    return null;
}

/**
 * Find company profile by user ID
 */
function db_company_by_user(array $data, int $userId): ?array
{
    foreach ($data['companies'] as $row) {
        if (isset($row['user_id']) && (int) $row['user_id'] === $userId) {
            return $row;
        }
    }

    return null;
}

/**
 * Find company by ID
 */
function db_company(array $data, int $id): ?array
{
    foreach ($data['companies'] as $row) {
        if (isset($row['id']) && (int) $row['id'] === $id) {
            return $row;
        }
    }

    return null;
}

/**
 * Find internship by ID
 */
function db_internship(array $data, int $id): ?array
{
    foreach ($data['internships'] as $row) {
        if (isset($row['id']) && (int) $row['id'] === $id) {
            return $row;
        }
    }

    return null;
}

/**
 * Sort records by newest date first
 */
function db_sort_newest(array &$rows, string $field = 'created_at'): void
{
    usort($rows, function ($a, $b) use ($field) {
        return strcmp(
            (string) ($b[$field] ?? ''),
            (string) ($a[$field] ?? '')
        );
    });
}

/**
 * Store a temporary message
 */
function flash(string $type, string $message): void
{
    $_SESSION['flash'] = [
        'type' => $type,
        'message' => $message,
    ];
}

/**
 * Retrieve and clear a temporary message
 */
function take_flash(): ?array
{
    $message = $_SESSION['flash'] ?? null;
    unset($_SESSION['flash']);

    return is_array($message) ? $message : null;
}

/**
 * Restrict access by user role
 */
function require_role(string $role, string $loginPath = '../login.php'): void
{
    if (
        !isset($_SESSION['user_id']) ||
        ($_SESSION['role'] ?? '') !== $role
    ) {
        header('Location: ' . $loginPath);
        exit;
    }
}

/**
 * Convert a status into a CSS class
 */
function status_class(string $status): string
{
    return strtolower(
        str_replace(' ', '-', trim($status))
    );
}
?>
